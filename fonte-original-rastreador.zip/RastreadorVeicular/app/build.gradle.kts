plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "br.com.rastreadorveicular"
    compileSdk = 35
    defaultConfig {
        applicationId = "br.com.rastreadorveicular"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0"
    }
}
dependencies {
    implementation("com.google.android.gms:play-services-location:21.3.0")
}
