package br.com.rastreadorveicular

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.net.Uri
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 60, 40, 40)
        }
        val title = TextView(this).apply {
            text = "GPS VEICULAR"
            textSize = 25f
        }
        status = TextView(this).apply {
            text = "Pronto para iniciar. Autorize a localização para usar o rastreador."
            textSize = 16f
            setPadding(0, 28, 0, 28)
        }
        val start = Button(this).apply {
            text = "INICIAR RASTREAMENTO"
            setOnClickListener { checkPermissionsAndStart() }
        }
        val stop = Button(this).apply {
            text = "PARAR RASTREAMENTO"
            setOnClickListener {
                stopService(Intent(this@MainActivity, LocationService::class.java))
                status.text = "Rastreamento parado."
            }
        }
        val settings = Button(this).apply {
            text = "CONFIGURAR PERMISSÕES"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:$packageName")))
            }
        }
        layout.addView(title)
        layout.addView(status)
        layout.addView(start)
        layout.addView(stop)
        layout.addView(settings)
        setContentView(layout)
    }

    private fun checkPermissionsAndStart() {
        val needed = mutableListOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )
        if (Build.VERSION.SDK_INT >= 33) needed.add(Manifest.permission.POST_NOTIFICATIONS)

        val missing = needed.filter {
            checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            requestPermissions(missing.toTypedArray(), 100)
            return
        }
        startTracker()
    }

    private fun startTracker() {
        val intent = Intent(this, LocationService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent)
        else startService(intent)
        status.text = "Rastreamento iniciado. Mantenha a notificação ativa."
        Toast.makeText(this, "GPS veicular iniciado", Toast.LENGTH_LONG).show()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 100) {
            if (grantResults.isNotEmpty() &&
                grantResults.all { it == PackageManager.PERMISSION_GRANTED }) {
                startTracker()
            } else {
                status.text = "Permissão não concedida. O rastreamento não pode iniciar."
            }
        }
    }
}
