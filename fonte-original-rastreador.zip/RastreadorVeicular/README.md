# GPS Veicular — versão inicial

Projeto Android nativo em Kotlin. Esta primeira etapa inicia um serviço de localização em primeiro plano e grava posições localmente no arquivo `posicoes.csv` dentro do armazenamento privado do aplicativo.

## Abrir e compilar
1. Instale o Android Studio em um computador.
2. Descompacte o projeto.
3. No Android Studio, escolha **Open** e selecione a pasta `RastreadorVeicular`.
4. Aguarde a sincronização do Gradle.
5. Conecte um Android por USB, habilite Depuração USB e execute o app.
6. No aparelho, conceda as permissões solicitadas e toque em **INICIAR RASTREAMENTO**.

## O que esta versão já faz
- Usa o provedor de localização do Google Play Services.
- Solicita atualizações aproximadamente a cada 15 segundos e/ou 10 metros (o Android pode ajustar a frequência).
- Mantém uma notificação visível enquanto o serviço está ativo.
- Grava data/hora, latitude, longitude, velocidade em m/s e precisão em `posicoes.csv`.
- O arquivo permanece privado no aplicativo; ainda não existe painel remoto nem envio ao Supabase.

## Próximas etapas
1. Configurar permissão de localização em segundo plano conforme a versão do Android.
2. Criar projeto e tabela no Supabase.
3. Implementar fila local e sincronização segura com Supabase.
4. Criar painel web com mapa e histórico.
5. Testar em movimento, tela apagada, reinicialização e perda de sinal.

## Observações importantes
- Esta é uma base inicial de desenvolvimento, não um APK final de produção.
- Para rastrear em segundo plano, o usuário deve conceder as permissões apropriadas nas configurações do Android. O fluxo de permissão varia conforme a versão do Android e o fabricante.
- Alguns fabricantes limitam serviços em segundo plano. Pode ser necessário permitir atividade em segundo plano e remover restrições de bateria para este app.
- O telefone precisa de GPS e internet móvel para transmitir posições. Sem internet, esta versão salva localmente; a sincronização será implementada na próxima etapa.
- O Android pode limitar a frequência das atualizações. Os 15 segundos são uma solicitação, não uma garantia.
- Use somente em veículo sob sua responsabilidade e com transparência e autorização de quem utiliza o veículo.
