// Copie este arquivo para firebase-config.js e preencha com o objeto público
// exibido em Configurações do projeto > Seus apps > App da Web.
// Não coloque service account, chave privada ou senha neste arquivo.
export const firebaseConfig = {
  apiKey: "COLE_API_KEY_PUBLICA_DO_FIREBASE",
  authDomain: "rastreador-arames-brasil.firebaseapp.com",
  projectId: "rastreador-arames-brasil",
  storageBucket: "rastreador-arames-brasil.firebasestorage.app",
  messagingSenderId: "COLE_SENDER_ID",
  appId: "COLE_APP_ID_WEB"
};
